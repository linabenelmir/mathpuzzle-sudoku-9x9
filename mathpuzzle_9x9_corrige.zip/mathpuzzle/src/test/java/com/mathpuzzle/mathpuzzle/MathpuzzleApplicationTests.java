package com.mathpuzzle.mathpuzzle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MathpuzzleApplicationTests {

	@Test
	void contextLoads() {
	}

}
