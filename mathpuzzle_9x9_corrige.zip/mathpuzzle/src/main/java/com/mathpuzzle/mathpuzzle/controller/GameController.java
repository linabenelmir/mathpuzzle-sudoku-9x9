package com.mathpuzzle.mathpuzzle.controller;

import com.mathpuzzle.mathpuzzle.model.User;
import com.mathpuzzle.mathpuzzle.repository.UserRepository;
import com.mathpuzzle.mathpuzzle.service.SudokuService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class GameController {

    private final SudokuService sudokuService;
    private final UserRepository userRepository;

    public GameController(SudokuService sudokuService, UserRepository userRepository) {
        this.sudokuService = sudokuService;
        this.userRepository = userRepository;
    }

    @GetMapping("/game")
    public String showLevel1(Model model, HttpSession session) {
        return startNewGame(1, model, session);
    }

    @GetMapping("/game2")
    public String showLevel2(Model model, HttpSession session) {
        User user = getConnectedUser(session);
        if (user == null) {
            return "redirect:/login";
        }
        if (user.getNiveau() < 2) {
            return "redirect:/game";
        }
        return startNewGame(2, model, session);
    }

    @GetMapping("/game3")
    public String showLevel3(Model model, HttpSession session) {
        User user = getConnectedUser(session);
        if (user == null) {
            return "redirect:/login";
        }
        if (user.getNiveau() < 3) {
            return "redirect:/game2";
        }
        return startNewGame(3, model, session);
    }

    @PostMapping("/checkSudoku")
    public String checkLevel1(HttpServletRequest request, HttpSession session, Model model) {
        return checkGame(1, request, session, model);
    }

    @PostMapping("/checkSudoku2")
    public String checkLevel2(HttpServletRequest request, HttpSession session, Model model) {
        return checkGame(2, request, session, model);
    }

    @PostMapping("/checkSudoku3")
    public String checkLevel3(HttpServletRequest request, HttpSession session, Model model) {
        return checkGame(3, request, session, model);
    }

    @PostMapping("/saveGame")
    public String saveLevel1(HttpServletRequest request, HttpSession session, Model model) {
        return saveGame(1, request, session, model);
    }

    @PostMapping("/saveGame2")
    public String saveLevel2(HttpServletRequest request, HttpSession session, Model model) {
        return saveGame(2, request, session, model);
    }

    @PostMapping("/saveGame3")
    public String saveLevel3(HttpServletRequest request, HttpSession session, Model model) {
        return saveGame(3, request, session, model);
    }

    @GetMapping("/resume")
    public String resumeGame(HttpSession session, Model model) {
        User user = getConnectedUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        if (isEmpty(user.getSavedGrid()) || isEmpty(user.getSavedSolution()) || isEmpty(user.getSavedUserGrid()) || user.getSavedNiveau() <= 0) {
            model.addAttribute("user", user);
            model.addAttribute("message", "Aucune partie sauvegardée n'est disponible.");
            return "home";
        }

        int level = user.getSavedNiveau();
        int[][] puzzle = deserializeGrid(user.getSavedGrid());
        int[][] solution = deserializeGrid(user.getSavedSolution());
        int[][] userGrid = deserializeGrid(user.getSavedUserGrid());

        storeGameInSession(level, puzzle, solution, Boolean.TRUE.equals(user.isSavedCompleted()), session);
        prepareGamePage(level, puzzle, userGrid, model);
        model.addAttribute("message", "Partie reprise avec succès.");
        return "game";
    }

    private String startNewGame(int level, Model model, HttpSession session) {
        User user = getConnectedUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        int[][] solution = sudokuService.generateRandomSolution();
        int[][] puzzle = sudokuService.generatePuzzle(solution, sudokuService.getRemovalCountForLevel(level));
        int[][] userGrid = sudokuService.copyGrid(puzzle);

        storeGameInSession(level, puzzle, solution, false, session);
        prepareGamePage(level, puzzle, userGrid, model);
        return "game";
    }

    private String checkGame(int level, HttpServletRequest request, HttpSession session, Model model) {
        User user = getConnectedUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        int[][] puzzle = getPuzzleFromSession(level, session);
        int[][] solution = getSolutionFromSession(level, session);
        if (puzzle == null || solution == null) {
            model.addAttribute("user", user);
            model.addAttribute("message", "La session de jeu a expiré. Veuillez relancer une nouvelle partie.");
            return "home";
        }

        int[][] userGrid = buildGridFromRequest(request, puzzle);
        prepareGamePage(level, puzzle, userGrid, model);

        if (!sudokuService.isGridComplete(userGrid)) {
            model.addAttribute("message", "Veuillez remplir toute la grille avant de vérifier.");
            return "game";
        }

        boolean correct = sudokuService.checkSolution(userGrid, solution);
        if (!correct) {
            model.addAttribute("message", "Solution incorrecte. Essayez encore.");
            return "game";
        }

        if (!Boolean.TRUE.equals(session.getAttribute(completedKey(level)))) {
            user.setScore(user.getScore() + sudokuService.getPointsForLevel(level));
            if (user.getNiveau() < level + 1 && level < 3) {
                user.setNiveau(level + 1);
            }
            if (level == 3 && user.getNiveau() < 3) {
                user.setNiveau(3);
            }
            userRepository.save(user);
            session.setAttribute(completedKey(level), true);
            session.setAttribute("connectedUserId", user.getId());
        }

        clearSavedGame(user);
        userRepository.save(user);

        model.addAttribute("message", level == 3 ? "Félicitations ! Vous avez terminé le Sudoku 9x9." : "Bravo ! Niveau " + level + " validé.");
        if (level < 3) {
            model.addAttribute("nextLevel", true);
        } else {
            model.addAttribute("finalLevel", true);
        }
        return "game";
    }

    private String saveGame(int level, HttpServletRequest request, HttpSession session, Model model) {
        User user = getConnectedUser(session);
        if (user == null) {
            return "redirect:/login";
        }

        int[][] puzzle = getPuzzleFromSession(level, session);
        int[][] solution = getSolutionFromSession(level, session);
        if (puzzle == null || solution == null) {
            model.addAttribute("user", user);
            model.addAttribute("message", "La session de jeu a expiré. Veuillez relancer une nouvelle partie.");
            return "home";
        }

        int[][] userGrid = buildGridFromRequest(request, puzzle);
        user.setSavedGrid(serializeGrid(puzzle));
        user.setSavedSolution(serializeGrid(solution));
        user.setSavedUserGrid(serializeGrid(userGrid));
        user.setSavedNiveau(level);
        user.setSavedCompleted(Boolean.TRUE.equals(session.getAttribute(completedKey(level))));
        userRepository.save(user);
        session.setAttribute("connectedUserId", user.getId());

        prepareGamePage(level, puzzle, userGrid, model);
        model.addAttribute("message", "Partie sauvegardée avec succès.");
        return "game";
    }

    private void prepareGamePage(int level, int[][] puzzle, int[][] userGrid, Model model) {
        model.addAttribute("grid", puzzle);
        model.addAttribute("userGrid", userGrid);
        model.addAttribute("level", level);
        model.addAttribute("levelTitle", "Niveau " + level + " - Sudoku 9x9");
        model.addAttribute("checkAction", level == 1 ? "/checkSudoku" : level == 2 ? "/checkSudoku2" : "/checkSudoku3");
        model.addAttribute("saveAction", level == 1 ? "/saveGame" : level == 2 ? "/saveGame2" : "/saveGame3");
        model.addAttribute("currentRoute", level == 1 ? "/game" : level == 2 ? "/game2" : "/game3");
        model.addAttribute("nextRoute", level == 1 ? "/game2" : "/game3");
    }

    private void storeGameInSession(int level, int[][] puzzle, int[][] solution, boolean completed, HttpSession session) {
        session.setAttribute(puzzleKey(level), puzzle);
        session.setAttribute(solutionKey(level), solution);
        session.setAttribute(completedKey(level), completed);
    }

    private int[][] getPuzzleFromSession(int level, HttpSession session) {
        Object puzzle = session.getAttribute(puzzleKey(level));
        return puzzle instanceof int[][] grid ? grid : null;
    }

    private int[][] getSolutionFromSession(int level, HttpSession session) {
        Object solution = session.getAttribute(solutionKey(level));
        return solution instanceof int[][] grid ? grid : null;
    }

    private int[][] buildGridFromRequest(HttpServletRequest request, int[][] puzzle) {
        int[][] userGrid = new int[9][9];
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (puzzle[row][col] != 0) {
                    userGrid[row][col] = puzzle[row][col];
                    continue;
                }
                String value = request.getParameter(cellName(row, col));
                if (value == null || value.isBlank()) {
                    userGrid[row][col] = 0;
                } else {
                    try {
                        userGrid[row][col] = Integer.parseInt(value.trim());
                    } catch (NumberFormatException exception) {
                        userGrid[row][col] = 0;
                    }
                }
            }
        }
        return userGrid;
    }

    private String cellName(int row, int col) {
        return "c" + (row + 1) + (col + 1);
    }

    private String puzzleKey(int level) {
        return "puzzleLevel" + level;
    }

    private String solutionKey(int level) {
        return "solutionLevel" + level;
    }

    private String completedKey(int level) {
        return "completedLevel" + level;
    }

    private String serializeGrid(int[][] grid) {
        StringBuilder builder = new StringBuilder();
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (builder.length() > 0) {
                    builder.append(',');
                }
                builder.append(grid[row][col]);
            }
        }
        return builder.toString();
    }

    private int[][] deserializeGrid(String data) {
        int[][] grid = new int[9][9];
        String[] values = data.split(",");
        int index = 0;
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                grid[row][col] = Integer.parseInt(values[index]);
                index++;
            }
        }
        return grid;
    }

    private boolean isEmpty(String value) {
        return value == null || value.isBlank();
    }

    private User getConnectedUser(HttpSession session) {
        Object userId = session.getAttribute("connectedUserId");
        if (!(userId instanceof Long id)) {
            return null;
        }
        return userRepository.findById(id).orElse(null);
    }

    private void clearSavedGame(User user) {
        user.setSavedGrid(null);
        user.setSavedSolution(null);
        user.setSavedUserGrid(null);
        user.setSavedNiveau(0);
        user.setSavedCompleted(false);
    }
}
