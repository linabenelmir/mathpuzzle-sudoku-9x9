package com.mathpuzzle.mathpuzzle.repository;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mathpuzzle.mathpuzzle.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
}