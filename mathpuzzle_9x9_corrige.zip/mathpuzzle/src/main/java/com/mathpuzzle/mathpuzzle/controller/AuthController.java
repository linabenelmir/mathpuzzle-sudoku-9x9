package com.mathpuzzle.mathpuzzle.controller;

import com.mathpuzzle.mathpuzzle.model.User;
import com.mathpuzzle.mathpuzzle.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.Optional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    private final UserRepository userRepository;

    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/home")
    public String showHomePage(HttpSession session, Model model) {
        User connectedUser = getFreshConnectedUser(session);
        model.addAttribute("user", connectedUser);
        return "home";
    }

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String username,
                           @RequestParam String password,
                           Model model) {

        String cleanUsername = username == null ? "" : username.trim();
        String cleanPassword = password == null ? "" : password.trim();

        if (cleanUsername.isEmpty() || cleanPassword.isEmpty()) {
            model.addAttribute("message", "Veuillez remplir tous les champs.");
            return "register";
        }

        Optional<User> existingUser = userRepository.findByUsername(cleanUsername);
        if (existingUser.isPresent()) {
            model.addAttribute("message", "Ce nom d'utilisateur est déjà utilisé.");
            return "register";
        }

        User user = new User();
        user.setUsername(cleanUsername);
        user.setPassword(cleanPassword);
        user.setScore(0);
        user.setNiveau(1);
        clearSavedGame(user);
        userRepository.save(user);

        model.addAttribute("message", "Inscription réussie. Vous pouvez maintenant vous connecter.");
        return "login";
    }

    @GetMapping("/login")
    public String showLoginPage(HttpSession session) {
        if (session.getAttribute("connectedUserId") != null) {
            return "redirect:/home";
        }
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        Model model,
                        HttpSession session,
                        HttpServletRequest request) {

        String cleanUsername = username == null ? "" : username.trim();
        String cleanPassword = password == null ? "" : password.trim();

        Optional<User> userOptional = userRepository.findByUsername(cleanUsername);
        if (userOptional.isEmpty() || !userOptional.get().getPassword().equals(cleanPassword)) {
            model.addAttribute("message", "Nom d'utilisateur ou mot de passe incorrect.");
            return "login";
        }

        session.invalidate();
        HttpSession newSession = request.getSession(true);
        User freshUser = userRepository.findById(userOptional.get().getId()).orElse(userOptional.get());
        newSession.setAttribute("connectedUserId", freshUser.getId());
        model.addAttribute("message", "Connexion réussie.");
        model.addAttribute("user", freshUser);
        return "home";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/score")
    public String showScore(HttpSession session, Model model) {
        User connectedUser = getFreshConnectedUser(session);
        if (connectedUser == null) {
            return "redirect:/login";
        }

        model.addAttribute("user", connectedUser);
        return "score";
    }

    private User getFreshConnectedUser(HttpSession session) {
        Object userId = session.getAttribute("connectedUserId");
        if (!(userId instanceof Long id)) {
            return null;
        }
        return userRepository.findById(id).orElse(null);
    }

    private void clearSavedGame(User user) {
        user.setSavedGrid(null);
        user.setSavedSolution(null);
        user.setSavedUserGrid(null);
        user.setSavedNiveau(0);
        user.setSavedCompleted(false);
    }
}
