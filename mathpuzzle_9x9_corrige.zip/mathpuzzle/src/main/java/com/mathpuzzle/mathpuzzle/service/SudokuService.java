package com.mathpuzzle.mathpuzzle.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.springframework.stereotype.Service;

@Service
public class SudokuService {

    private final Random random = new Random();

    public int[][] generateRandomSolution() {
        int[][] baseGrid = createBaseSolution();
        shuffleNumbers(baseGrid);
        shuffleRowsWithinBands(baseGrid);
        shuffleColumnsWithinStacks(baseGrid);
        shuffleBands(baseGrid);
        shuffleStacks(baseGrid);
        return baseGrid;
    }

    public int[][] generatePuzzle(int[][] solution, int removalCount) {
        int[][] puzzle = copyGrid(solution);
        List<Integer> positions = new ArrayList<>();
        for (int index = 0; index < 81; index++) {
            positions.add(index);
        }
        Collections.shuffle(positions, random);
        for (int i = 0; i < removalCount && i < positions.size(); i++) {
            int position = positions.get(i);
            puzzle[position / 9][position % 9] = 0;
        }
        return puzzle;
    }

    public int getRemovalCountForLevel(int level) {
        if (level == 1) {
            return 35;
        }
        if (level == 2) {
            return 45;
        }
        return 55;
    }

    public int getPointsForLevel(int level) {
        if (level == 1) {
            return 10;
        }
        if (level == 2) {
            return 20;
        }
        return 30;
    }

    public boolean isGridComplete(int[][] grid) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (grid[row][col] < 1 || grid[row][col] > 9) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean checkSolution(int[][] userGrid, int[][] solution) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (userGrid[row][col] != solution[row][col]) {
                    return false;
                }
            }
        }
        return hasValidRows(userGrid) && hasValidColumns(userGrid) && hasValidBlocks(userGrid);
    }

    public int[][] copyGrid(int[][] original) {
        int[][] copy = new int[original.length][original[0].length];
        for (int row = 0; row < original.length; row++) {
            System.arraycopy(original[row], 0, copy[row], 0, original[row].length);
        }
        return copy;
    }

    private int[][] createBaseSolution() {
        int[][] grid = new int[9][9];
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                grid[row][col] = ((row * 3) + (row / 3) + col) % 9 + 1;
            }
        }
        return grid;
    }

    private void shuffleNumbers(int[][] grid) {
        List<Integer> numbers = new ArrayList<>();
        for (int number = 1; number <= 9; number++) {
            numbers.add(number);
        }
        Collections.shuffle(numbers, random);

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                grid[row][col] = numbers.get(grid[row][col] - 1);
            }
        }
    }

    private void shuffleRowsWithinBands(int[][] grid) {
        for (int band = 0; band < 3; band++) {
            int start = band * 3;
            swapRows(grid, start + random.nextInt(3), start + random.nextInt(3));
            swapRows(grid, start + random.nextInt(3), start + random.nextInt(3));
        }
    }

    private void shuffleColumnsWithinStacks(int[][] grid) {
        for (int stack = 0; stack < 3; stack++) {
            int start = stack * 3;
            swapColumns(grid, start + random.nextInt(3), start + random.nextInt(3));
            swapColumns(grid, start + random.nextInt(3), start + random.nextInt(3));
        }
    }

    private void shuffleBands(int[][] grid) {
        swapRowBands(grid, random.nextInt(3), random.nextInt(3));
    }

    private void shuffleStacks(int[][] grid) {
        swapColumnStacks(grid, random.nextInt(3), random.nextInt(3));
    }

    private void swapRows(int[][] grid, int firstRow, int secondRow) {
        int[] temp = grid[firstRow];
        grid[firstRow] = grid[secondRow];
        grid[secondRow] = temp;
    }

    private void swapColumns(int[][] grid, int firstColumn, int secondColumn) {
        for (int row = 0; row < 9; row++) {
            int temp = grid[row][firstColumn];
            grid[row][firstColumn] = grid[row][secondColumn];
            grid[row][secondColumn] = temp;
        }
    }

    private void swapRowBands(int[][] grid, int firstBand, int secondBand) {
        if (firstBand == secondBand) {
            return;
        }
        for (int offset = 0; offset < 3; offset++) {
            swapRows(grid, firstBand * 3 + offset, secondBand * 3 + offset);
        }
    }

    private void swapColumnStacks(int[][] grid, int firstStack, int secondStack) {
        if (firstStack == secondStack) {
            return;
        }
        for (int offset = 0; offset < 3; offset++) {
            swapColumns(grid, firstStack * 3 + offset, secondStack * 3 + offset);
        }
    }

    private boolean hasValidRows(int[][] grid) {
        for (int row = 0; row < 9; row++) {
            if (!containsDigitsOneToNine(grid[row])) {
                return false;
            }
        }
        return true;
    }

    private boolean hasValidColumns(int[][] grid) {
        for (int col = 0; col < 9; col++) {
            int[] column = new int[9];
            for (int row = 0; row < 9; row++) {
                column[row] = grid[row][col];
            }
            if (!containsDigitsOneToNine(column)) {
                return false;
            }
        }
        return true;
    }

    private boolean hasValidBlocks(int[][] grid) {
        for (int startRow = 0; startRow < 9; startRow += 3) {
            for (int startCol = 0; startCol < 9; startCol += 3) {
                int[] block = new int[9];
                int index = 0;
                for (int row = startRow; row < startRow + 3; row++) {
                    for (int col = startCol; col < startCol + 3; col++) {
                        block[index++] = grid[row][col];
                    }
                }
                if (!containsDigitsOneToNine(block)) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean containsDigitsOneToNine(int[] values) {
        boolean[] seen = new boolean[10];
        for (int value : values) {
            if (value < 1 || value > 9 || seen[value]) {
                return false;
            }
            seen[value] = true;
        }
        return true;
    }
}
