package com.mathpuzzle.mathpuzzle.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password;
    private int score;
    private int niveau;
    private String savedGrid;
    private int savedNiveau;
    private String savedSolution;
    private String savedUserGrid;
    private Boolean savedCompleted;

    public User() {
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getNiveau() {
        return niveau;
    }

    public void setNiveau(int niveau) {
        this.niveau = niveau;
    }

    public String getSavedGrid() {
        return savedGrid;
    }

    public void setSavedGrid(String savedGrid) {
        this.savedGrid = savedGrid;
    }

    public int getSavedNiveau() {
        return savedNiveau;
    }

    public void setSavedNiveau(int savedNiveau) {
        this.savedNiveau = savedNiveau;
    }

    public String getSavedSolution() {
        return savedSolution;
    }

    public void setSavedSolution(String savedSolution) {
        this.savedSolution = savedSolution;
    }

    public String getSavedUserGrid() {
        return savedUserGrid;
    }

    public void setSavedUserGrid(String savedUserGrid) {
        this.savedUserGrid = savedUserGrid;
    }

    public Boolean isSavedCompleted() {
        return savedCompleted;
    }

    public void setSavedCompleted(Boolean savedCompleted) {
        this.savedCompleted = savedCompleted;
    }
}
