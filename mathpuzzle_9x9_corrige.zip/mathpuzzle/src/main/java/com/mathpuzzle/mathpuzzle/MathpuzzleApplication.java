package com.mathpuzzle.mathpuzzle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MathpuzzleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MathpuzzleApplication.class, args);
	}

}
